# ICT.OS — Trading Journal (appli mobile, Supabase)

Version PWA installable de ton Trading Journal : compte utilisateur et
synchronisation automatique entre tous tes appareils (téléphone, tablette,
ordinateur).

Modules : **Dashboard**, **Trading Journal**, **Daily Review**, **Weekly
Planner**, **Daily Planner**, **Statistiques**, **Goals**, **Comptes**,
**Setups** — repris de tes notes manuscrites.

## 1. Créer la base de données Supabase

1. Crée un projet sur [supabase.com](https://supabase.com) (gratuit).
2. Dans le menu de gauche, ouvre **SQL Editor** → **New query**.
3. Colle tout le contenu du fichier `schema.sql` et clique sur **Run**.
   Cela crée les 8 tables (accounts, setups, trades, daily_reviews,
   weekly_planners, economic_news, daily_planners, goals), les règles de
   sécurité (chacun ne voit que ses propres données), et les buckets de
   stockage pour les screenshots de trades et les photos de Daily Review.
4. Va dans **Authentication → Providers**, vérifie que "Email" est activé
   (c'est le cas par défaut).
   - Pour tester rapidement sans configurer l'envoi d'email : Authentication
     → Settings → décoche "Confirm email" (à réactiver plus tard si tu veux
     une vraie vérification par email).

Le script est **100% sûr à ré-exécuter** plus tard (si tu ajoutes des
colonnes) : il ne supprime jamais de données existantes.

## 2. Connecter l'appli à ton projet

1. **Project URL** : clique sur le bouton **"Connect"** en haut de la page du
   projet (à côté du nom) — cela affiche l'URL. Sinon, elle se déduit de
   l'adresse dans la barre de ton navigateur quand tu es sur le dashboard du
   projet : `https://dashboard/project/<ref>/...` → ton URL est
   `https://<ref>.supabase.co`.
2. **Clé API** : va dans **Project Settings → API Keys**. Sur l'onglet
   **"Publishable and secret API keys"**, copie la **Publishable key**
   (`sb_publishable_...`). Elle fonctionne avec les règles de sécurité (RLS)
   activées dans `schema.sql`.
3. Ouvre `app.js` et remplace en haut du fichier :
   ```js
   const SUPABASE_URL = "https://TON-PROJET.supabase.co";
   const SUPABASE_ANON_KEY = "sb_publishable_...."; // ta Publishable key
   ```
   par tes propres valeurs.

## 3. Mettre l'appli en ligne (nécessaire pour l'installer sur le téléphone)

Une PWA doit être servie en HTTPS pour être installable — impossible en
ouvrant simplement le fichier depuis le téléphone. Solution la plus simple,
gratuite, sans configuration serveur : **GitHub Pages**.

1. Crée un dépôt GitHub (public ou privé) et mets-y les fichiers de ce
   dossier (`index.html`, `app.js`, `manifest.json`, `sw.js`, et deux icônes
   `icon-192.png` / `icon-512.png` que tu ajoutes toi-même).
2. Dans le dépôt : **Settings → Pages → Source : "Deploy from a branch"**,
   branche `main`, dossier `/ (root)`. Sauvegarde.
3. Après ~1 minute, ton appli est accessible à une adresse du type
   `https://<ton-pseudo>.github.io/<nom-du-repo>/`.

(Netlify ou Vercel fonctionnent aussi, en glissant simplement le dossier sur
leur interface.)

## 4. Installer sur ton téléphone

- **iPhone (Safari)** : ouvre le lien → bouton Partager → "Sur l'écran
  d'accueil".
- **Android (Chrome)** : ouvre le lien → menu ⋮ → "Installer l'application"
  (ou "Ajouter à l'écran d'accueil").

L'icône apparaît alors comme une vraie appli, en plein écran, sans barre de
navigateur.

## 5. Utilisation multi-appareils

Crée ton compte une première fois (email + mot de passe) depuis un appareil.
Connecte-toi ensuite avec le même compte sur tes autres appareils : toutes
les données (comptes, trades, reviews, planners, goals) apparaissent
automatiquement, et toute modification se synchronise en temps réel via
Supabase.

## Comment ça correspond à tes notes

- **Dashboard** → cartes cliquables (Total Balance, Total Profit, Winrate,
  Trades du mois, Goals en cours) + panneau Comptes + panneau Goals en cours
  + panneau news éco de la semaine. Raccourcis "+ New Trade / + Daily
  Review / + Goals" en haut de l'écran.
- **Trading Journal** → tous les champs de ta liste (date, ticker, direction,
  compte, setup, contrats, risk 0.25/0.50/1.00, session Asia/London/NY,
  win/loss, screenshot en pièce jointe, lien vers une Daily Review).
- **Comptes** → nom, starting balance, total balance et ROI **calculés
  automatiquement** à partir des trades liés, nombre de trades, target.
- **Setups** → créables librement, réutilisés en liste déroulante dans le
  formulaire de trade ; winrate calculé automatiquement par setup.
- **Weekly Planner** → checklist des biais de la semaine (ajout/coche/suppr.
  en un clic) + tableau de news économiques et implications.
- **Daily Planner** → checklist des biais du jour + news économiques du jour
  reprises automatiquement depuis le Weekly Planner de la semaine en cours.
- **Daily Review** → modèle type avec les 4 photos (Daily / Hour / 15min /
  5min), récap par session (London/Asia/NY), et sélectionnable comme lien
  depuis un trade du journal.
- **Statistiques** → session la plus réussie, setup le plus réussi, gains
  jour/semaine/mois, calculés en direct depuis le cache des trades.

## Ce qui reste à faire toi-même

- Ajouter tes deux icônes `icon-192.png` et `icon-512.png` à côté des
  fichiers (n'importe quel générateur d'icône PWA en ligne fait l'affaire).
- Le remplissage **automatique** du calendrier de news éco à partir d'un
  document envoyé (mentionné dans tes notes) demande un import/parsing
  dédié — pour l'instant les news s'ajoutent manuellement dans le Weekly
  Planner ; dis-moi si tu veux qu'on branche cet import ensuite.

## 🆕 Mise à jour majeure — refonte complète

**Une seule action à faire** : recolle **tout** le `schema.sql` dans Supabase →
SQL Editor → Run (ajoute les colonnes/tables manquantes sans rien effacer),
puis remets **tous** les fichiers à jour en ligne (le zip complet).

### Nouveautés

- **Design** : nouvelle palette (clair/sombre), police Inter (texte) / Manrope
  (titres) / JetBrains Mono (chiffres), icônes Phosphor, coins arrondis
  harmonisés, logo centré en haut de la sidebar.
- **Tableaux responsives** : sur mobile, chaque ligne devient une carte
  empilée (label + valeur) — appliqué à tous les tableaux de l'app.
- **Dashboard réorganisé** : colonne de gauche (Total Balance, Total Profit,
  Winrate, Trades du mois, Goals en cours, Comptes, Goals) / colonne de
  droite dédiée aux **comptes examen** (temps restant en grand, statut
  validé/échoué/en cours).
- **Trading Journal** : champ **RR** ajouté ; le lien vers une Daily Review
  se fait maintenant **depuis la Daily Review** (pas depuis le trade).
- **Weekly Planner** : ordre de session Pre-Market → London rétabli ; les
  news économiques peuvent être marquées **"Toute la journée"** (pas
  d'heure précise) ; nouveaux types d'évènements (BOE, Trump Speak, Core
  PCE, etc. suggérés en saisie).
- **Statistiques** : la courbe d'equity réelle, les sparklines par setup et
  les anneaux de drawdown restant remplacent les anciennes barres.
- **Comptes** : séparés en **Comptes examen** / **Comptes actifs**, avec
  puces d'alerte (drawdown, progression vers l'objectif, P/L du jour,
  temps restant).
- **Wallet** (nouvel onglet) : suivi du bénéfice réel généré, des retraits
  et de l'épargne, indépendant des comptes de trading.
- **Notifications** : cloche dans la sidebar avec liste d'alertes
  (rappel de compléter le journal, échéances de goals, alertes de compte
  examen…), préférence "Urgentes" / "Toutes", et notifications navigateur
  si tu accordes la permission (nécessite que l'onglet soit ouvert — pas
  de vraies push notifications en arrière-plan sans serveur dédié).

### Limite connue

Les "notifications" sont calculées **côté client**, pendant que l'appli est
ouverte dans le navigateur — ce n'est pas un vrai système de push en
arrière-plan (qui demanderait un serveur/service de notifications push,
hors du périmètre d'une PWA 100% statique + Supabase). Si tu veux de
vraies notifications même appli fermée, il faudrait ajouter un service
worker de push + une fonction Supabase Edge planifiée — dis-moi si tu veux
qu'on l'implémente dans un second temps.
