-- ============================================================
--  ICT.OS — TRADING JOURNAL — SCHÉMA COMPLET (Supabase)
--  À coller EN ENTIER dans Supabase → SQL Editor → New query → Run.
--  100% sûr à ré-exécuter :
--    • create table IF NOT EXISTS   → n'écrase aucune donnée
--    • alter ... add column IF NOT EXISTS → ajoute les colonnes manquantes
--    • drop policy IF EXISTS avant chaque create policy
--    • le bloc "storage" (screenshots / photos) est protégé :
--      s'il échoue (droits), il est ignoré sans bloquer le reste.
-- ============================================================

-- ============================================================
--  1) TABLES
-- ============================================================

create table if not exists accounts (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  nom text, starting_balance numeric default 0, target numeric,
  date_creation text
);

create table if not exists setups (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  nom text, description text, date_creation text
);

create table if not exists daily_reviews (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  review_date text,
  photo_daily_path text, photo_hour_path text, photo_15min_path text, photo_5min_path text,
  recap_london text, recap_asia text, recap_ny text,
  notes text, date_creation text
);

create table if not exists trades (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  account_id bigint, setup_id bigint, daily_review_id bigint,
  trade_date text, ticker text, direction text,
  contrats numeric default 1, risk_percent numeric default 0.25,
  session text, resultat text, profit_loss numeric default 0,
  screenshot_path text, notes text, date_creation text
);

create table if not exists weekly_planners (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  week_start_date text, bias_checklist jsonb default '[]'::jsonb,
  date_creation text
);

create table if not exists economic_news (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  weekly_planner_id bigint,
  date_event text, event text, impact text, implication text,
  event_type text, heure text,
  date_creation text
);

create table if not exists daily_planners (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  weekly_planner_id bigint,
  planner_date text, bias_checklist jsonb default '[]'::jsonb,
  date_creation text
);

create table if not exists goals (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  titre text, description text, target_value numeric, current_value numeric default 0,
  deadline text, statut text, date_creation text
);

-- ============================================================
--  2) COLONNES (ajout des manquantes si une table existait déjà)
-- ============================================================
alter table trades add column if not exists daily_review_id bigint;
alter table trades add column if not exists screenshot_path text;
alter table trades add column if not exists rr numeric;
alter table daily_planners add column if not exists weekly_planner_id bigint;
alter table economic_news add column if not exists weekly_planner_id bigint;
alter table economic_news add column if not exists event_type text;
alter table economic_news add column if not exists heure text;
alter table accounts add column if not exists account_type text default 'actif';
alter table accounts add column if not exists deadline_date text;
alter table accounts add column if not exists max_drawdown_percent numeric;
alter table accounts add column if not exists daily_loss_limit_percent numeric;
alter table accounts add column if not exists account_status text default 'en_cours';

create table if not exists wallet_entries (
  id bigint generated always as identity primary key,
  user_id uuid references auth.users(id) on delete cascade not null,
  entry_type text, amount numeric, entry_date text, notes text, date_creation text
);
alter table wallet_entries enable row level security;
drop policy if exists "wallet_entries_owner" on wallet_entries;
create policy "wallet_entries_owner" on wallet_entries for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ============================================================
--  3) SÉCURITÉ (RLS) : chacun ne voit que ses propres données
-- ============================================================
alter table accounts enable row level security;
alter table setups enable row level security;
alter table daily_reviews enable row level security;
alter table trades enable row level security;
alter table weekly_planners enable row level security;
alter table economic_news enable row level security;
alter table daily_planners enable row level security;
alter table goals enable row level security;

drop policy if exists "accounts_owner" on accounts;
create policy "accounts_owner" on accounts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "setups_owner" on setups;
create policy "setups_owner" on setups for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "daily_reviews_owner" on daily_reviews;
create policy "daily_reviews_owner" on daily_reviews for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "trades_owner" on trades;
create policy "trades_owner" on trades for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "weekly_planners_owner" on weekly_planners;
create policy "weekly_planners_owner" on weekly_planners for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "economic_news_owner" on economic_news;
create policy "economic_news_owner" on economic_news for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "daily_planners_owner" on daily_planners;
create policy "daily_planners_owner" on daily_planners for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "goals_owner" on goals;
create policy "goals_owner" on goals for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ============================================================
--  4) STOCKAGE (screenshots de trades + photos de Daily Review)
--  Bloc protégé : s'il échoue (droits sur storage.objects), il est
--  ignoré sans erreur et n'empêche PAS le reste de fonctionner.
--  (Les buckets peuvent sinon être créés à la main dans Storage,
--  noms exacts "trade-screenshots" et "review-photos", privés.)
-- ============================================================
do $$
begin
  insert into storage.buckets (id, name, public) values ('trade-screenshots', 'trade-screenshots', false) on conflict (id) do nothing;
  insert into storage.buckets (id, name, public) values ('review-photos', 'review-photos', false) on conflict (id) do nothing;
exception when others then
  raise notice 'Buckets non créés (%). Sans incidence sur le reste.', sqlerrm;
end $$;

do $$
begin
  execute 'drop policy if exists "trade_screenshots_rw" on storage.objects';
  execute $p$
    create policy "trade_screenshots_rw" on storage.objects for all to authenticated
      using (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text)
      with check (bucket_id = 'trade-screenshots' and (storage.foldername(name))[1] = auth.uid()::text)
  $p$;
  execute 'drop policy if exists "review_photos_rw" on storage.objects';
  execute $p$
    create policy "review_photos_rw" on storage.objects for all to authenticated
      using (bucket_id = 'review-photos' and (storage.foldername(name))[1] = auth.uid()::text)
      with check (bucket_id = 'review-photos' and (storage.foldername(name))[1] = auth.uid()::text)
  $p$;
exception when others then
  raise notice 'Règles storage non créées (%). Sans incidence sur le reste.', sqlerrm;
end $$;

-- ✅ Terminé. Si tout s'est bien passé : "Success. No rows returned".
